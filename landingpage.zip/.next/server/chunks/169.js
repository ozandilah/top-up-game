"use strict";
exports.id = 169;
exports.ids = [169];
exports.modules = {

/***/ 169:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ callAPI)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, js_cookie__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, js_cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


async function callAPI({ url , method , data , token , serverToken  }) {
    let headers = {};
    if (serverToken) {
        headers = {
            Authorization: `Bearer ${serverToken}`
        };
    } else if (token) {
        const tokenCookies = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("token");
        if (tokenCookies) {
            const jwtToken = atob(tokenCookies);
            headers = {
                Authorization: `Bearer ${jwtToken}`
            };
        }
    }
    const response = await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])({
        url,
        method,
        data,
        headers
    }).catch((error)=>error.response);
    if (response.status > 300) {
        const res = {
            error: true,
            message: response.data.message,
            data: null
        };
        return res;
    }
    const { length  } = Object.keys(response.data);
    const res = {
        error: false,
        message: "success",
        data: length > 1 ? response.data : response.data.data
    };
    return res;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;