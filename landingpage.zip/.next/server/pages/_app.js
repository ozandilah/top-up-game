(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_utilities_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5654);
/* harmony import */ var _styles_utilities_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_utilities_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_homepage_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var _styles_homepage_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_homepage_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_detail_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8290);
/* harmony import */ var _styles_detail_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_detail_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_checkout_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4275);
/* harmony import */ var _styles_checkout_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_checkout_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_complete_checkout_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1525);
/* harmony import */ var _styles_complete_checkout_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_complete_checkout_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_sign_in_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2775);
/* harmony import */ var _styles_sign_in_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_sign_in_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _styles_sign_up_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6331);
/* harmony import */ var _styles_sign_up_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_sign_up_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_sign_up_photo_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3634);
/* harmony import */ var _styles_sign_up_photo_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_sign_up_photo_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _styles_sign_up_success_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(413);
/* harmony import */ var _styles_sign_up_success_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_styles_sign_up_success_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _styles_404_not_found_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9133);
/* harmony import */ var _styles_404_not_found_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_404_not_found_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _styles_sidebar_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8676);
/* harmony import */ var _styles_sidebar_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_sidebar_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _styles_overview_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5834);
/* harmony import */ var _styles_overview_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_overview_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _styles_transactions_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8106);
/* harmony import */ var _styles_transactions_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_styles_transactions_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _styles_transactions_detail_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7338);
/* harmony import */ var _styles_transactions_detail_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_styles_transactions_detail_css__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _styles_edit_profile_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4944);
/* harmony import */ var _styles_edit_profile_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_styles_edit_profile_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _styles_navbar_log_in_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3853);
/* harmony import */ var _styles_navbar_log_in_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_styles_navbar_log_in_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_17__]);
react_toastify__WEBPACK_IMPORTED_MODULE_17__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




















function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_19___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        href: "https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css",
                        rel: "stylesheet",
                        integrity: "sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x",
                        crossOrigin: "anonymous"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        href: "https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap",
                        rel: "stylesheet"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        href: "https://unpkg.com/aos@2.3.1/dist/aos.css",
                        rel: "stylesheet"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        src: "https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js",
                        integrity: "sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4",
                        crossOrigin: "anonymous"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_17__.ToastContainer, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 9133:
/***/ (() => {



/***/ }),

/***/ 4275:
/***/ (() => {



/***/ }),

/***/ 1525:
/***/ (() => {



/***/ }),

/***/ 8290:
/***/ (() => {



/***/ }),

/***/ 4944:
/***/ (() => {



/***/ }),

/***/ 1823:
/***/ (() => {



/***/ }),

/***/ 3853:
/***/ (() => {



/***/ }),

/***/ 5834:
/***/ (() => {



/***/ }),

/***/ 8676:
/***/ (() => {



/***/ }),

/***/ 2775:
/***/ (() => {



/***/ }),

/***/ 3634:
/***/ (() => {



/***/ }),

/***/ 413:
/***/ (() => {



/***/ }),

/***/ 6331:
/***/ (() => {



/***/ }),

/***/ 7338:
/***/ (() => {



/***/ }),

/***/ 8106:
/***/ (() => {



/***/ }),

/***/ 5654:
/***/ (() => {



/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893], () => (__webpack_exec__(4178)));
module.exports = __webpack_exports__;

})();